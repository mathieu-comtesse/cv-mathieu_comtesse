import * as THREE from 'three';
import { waterTime } from './water.js';
import { groundHeight, randomGenerator } from './math.js';

// Pigment stays attached to the rest surface, so it never flickers while swimming.
const paint = `
float ph(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float pn(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(ph(i),ph(i+vec2(1,0)),f.x),mix(ph(i+vec2(0,1)),ph(i+1.),f.x),f.y);}
vec3 gouache(vec3 pigment,vec2 p){
 float wash=pn(p*11.)*.6+pn(p*27.+17.)*.4;
 float tooth=ph(floor(p*185.));
 float dry=smoothstep(.64,.86,pn(p*83.+8.))*smoothstep(.32,.78,tooth);
 vec3 color=pigment*(.65+.58*wash)*(.85+.28*tooth);
 color=mix(color,pigment*.72+vec3(.18,.14,.09),dry*.42);
 return color;
}`;

export const gouacheFishFragment=`
varying vec3 vNormal;varying vec3 vSkinPoint;varying vec2 vFishUV;varying float vFishPart;varying float vCobaltTone;
${paint}
void main(){
 vec2 p=vSkinPoint.xy+vec2(vCobaltTone*7.,0.);
 vec3 pigment=vCobaltTone<.42?vec3(.47,.065,.027):vCobaltTone<.67?vec3(.48,.32,.065):vCobaltTone<.88?vec3(.018,.058,.10):vec3(.54,.39,.24);
 float bleed=pn(p*42.);
 if(vFishPart<.5){
   if(vCobaltTone>=.42&&vCobaltTone<.67){
     float stripe=sin(vSkinPoint.x*50.+pn(p*19.)*2.+sin(vSkinPoint.y*19.));
     pigment=mix(pigment,vec3(.018,.055,.10),smoothstep(.15,.65,stripe)*.92);
   }else if(vCobaltTone<.42){
     vec2 cell=fract(p*22.)-.5;
     float fleck=1.-smoothstep(.10,.27,length(cell)+bleed*.12);
     pigment=mix(pigment,vec3(.57,.19,.10),fleck*.52);
   }
 }
 vec3 color=gouache(pigment,p);
 // A softly painted eye, with pigment showing through the dark mark.
 if(vFishPart>6.5&&vFishPart<8.5)color=gouache(vec3(.012,.023,.027),p)*(.75+bleed*.45);
 if(vFishPart>8.5&&vFishPart<11.5)color=mix(color,gouache(pigment*.68,p),.65);
 vec3 n=normalize(vNormal);
 float edge=1.-abs(n.z);
 float paper=ph(floor(p*280.));
 if(edge>.92 && paper>.62+bleed*.30)discard;
 gl_FragColor=vec4(color,1.);
}`;

export function createGouachePlants(scene){
 const rng=randomGenerator(7391),positions=[],uvs=[],tones=[],indices=[];
 // Broad, scalloped kelp fronds, with rounded side lobes like the painted coral.
 for(let i=0;i<42;i++){
   const x=(i%2?-1:1)*(6.1+rng()*4.2),z=.25+rng()*2.5,y=groundHeight(x,z)-.2;
   const height=.48+rng()*1.3,width=.12+rng()*.15,bend=(rng()-.5)*.9,base=positions.length/3,phase=rng()*6.28,tone=rng();
   for(let k=0;k<=32;k++){
     const t=k/32;
     const rounded=Math.pow(Math.max(0.,Math.sin(Math.PI*t)),.45);
     const lobes=.85+.15*Math.cos(t*Math.PI*6+phase);
     for(const sign of [-1,1]){
       positions.push(x+bend*t*t+Math.sin(t*6+phase)*.08*t+sign*width*rounded*lobes,y+height*t,z);
       uvs.push(t,(sign+1)/2);tones.push(tone);
     }
     if(k<32){const b=base+k*2;indices.push(b,b+1,b+2,b+1,b+3,b+2);}
   }
 }
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));g.setAttribute('tone',new THREE.Float32BufferAttribute(tones,1));g.setIndex(indices);
 const material=new THREE.ShaderMaterial({side:THREE.DoubleSide,uniforms:{time:waterTime,motion:{value:.55}},
 vertexShader:`uniform float time,motion;attribute float tone;varying vec2 leafUV;varying vec3 leafPoint;varying float leafTone;void main(){leafUV=uv;leafPoint=position;leafTone=tone;vec3 p=position;p.x+=sin(time*.43+p.x*.8+p.z)*.19*uv.x*uv.x*motion;p.z+=cos(time*.32+p.x)*.07*uv.x*motion;gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}`,
 fragmentShader:`varying vec2 leafUV;varying vec3 leafPoint;varying float leafTone;${paint}
 void main(){vec2 p=leafPoint.xy;float n=pn(p*33.);float edge=abs(leafUV.y-.5)*2.;if(edge>.91+n*.09)discard;
 vec3 pigment=leafTone<.50?vec3(.11,.20,.067):leafTone<.69?vec3(.39,.24,.06):leafTone<.88?vec3(.35,.072,.035):vec3(.36,.19,.13);
 float marks=smoothstep(.64,.78,pn(p*vec2(25.,14.)));
 pigment=mix(pigment,pigment*1.6+vec3(.04,.024,0.),marks*.52);
 gl_FragColor=vec4(gouache(pigment,p)*(.8+.2*leafUV.x),1.);}`});
 const mesh=new THREE.Mesh(g,material);mesh.name='Gouache painted kelp';mesh.onBeforeRender=()=>{material.uniforms.motion.value=window.habitatOptions?.motion??.55;};scene.add(mesh);
 return {mesh,thickets:[],stats:{triangles:indices.length/3,vertices:positions.length/3}};
}

export const gouacheBubbleFragment=`varying float vSeed,vKind,vFade;${paint}
void main(){vec2 p=(gl_PointCoord-.5)*2.;float a=atan(p.y,p.x);float irregular=.025*sin(a*3.+vSeed*23.)+.018*sin(a*7.+vSeed*31.);float r=length(p)+irregular;
 if(r>1.)discard;
 vec2 paper=gl_PointCoord*2.+vSeed*31.;float tooth=ph(floor(paper*31.));float wash=pn(paper*12.);
 vec3 pigment=mix(vec3(.11,.24,.29),vec3(.50,.40,.26),vSeed);
 float opacity;
 if(vKind>.5){float ring=smoothstep(.52,.64+wash*.06,r)*(1.-smoothstep(.79,.97,r));float dry=smoothstep(.08,.44,wash+tooth*.35);opacity=ring*dry*(.38+.32*tooth);}
 else opacity=(1.-smoothstep(0.,1.,r))*.22;
 gl_FragColor=vec4(gouache(pigment,paper),opacity*vFade);}`;

