import * as THREE from 'three';
import { createGouachePlants, gouacheFishFragment, gouacheBubbleFragment } from './gouache.js';
import { waterTime } from './water.js';
import { groundHeight, randomGenerator } from './math.js';
const isReef=()=>document.documentElement.dataset.theme==='reef';

// An illustrated plate plus live refraction, 3D plants, particles and fish.
// The illustration is not presented as a fully modelled 3D landscape.
export async function createCobaltEnvironment(scene) {
  const texture=await new THREE.TextureLoader().loadAsync(isReef()?'assets/recif-gouache.png':'assets/abysses-cobalt.png');
  texture.colorSpace=THREE.SRGBColorSpace;
  const material=new THREE.ShaderMaterial({
    uniforms:{plate:{value:texture},time:waterTime,aspect:{value:16/9},artAspect:{value:texture.image.width/texture.image.height},motion:{value:.55},reef:{value:isReef()?1:0}},
    depthWrite:false, depthTest:false,
    vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.99999,1.);}',
    fragmentShader:`uniform sampler2D plate;uniform float time,aspect,artAspect,motion,reef;varying vec2 vUv;
    void main(){
      vec2 uv=vUv;
      if(aspect>artAspect)uv.y=(uv.y-.5)*artAspect/aspect+.5;else uv.x=(uv.x-.5)*aspect/artAspect+.5;
      vec3 raw=texture2D(plate,uv).rgb;
      float water=smoothstep(.01,.22,raw.b-max(raw.r,raw.g));
      vec2 drift=vec2(sin(uv.y*23.+time*.23),cos(uv.x*21.-time*.19))*.0018*motion*water;
      float vegetation=(1.-water)*reef;
      drift.x+=sin(uv.y*15.+uv.x*9.+time*.44)*.0025*vegetation*motion;
      drift.y+=sin(uv.x*19.-time*.31)*.0008*vegetation*motion;
      vec3 color=texture2D(plate,clamp(uv+drift,.001,.999)).rgb;
      float shimmer=sin(uv.x*29.+uv.y*17.+time*.31)*sin(uv.y*33.-time*.17);
      color*=1.+shimmer*.065*water*motion;
      gl_FragColor=vec4(color,1.);
    }`
  });
  const backdrop=new THREE.Mesh(new THREE.PlaneGeometry(2,2),material);
  backdrop.frustumCulled=false;backdrop.renderOrder=-100;
  backdrop.onBeforeRender=(renderer,scene,camera)=>{material.uniforms.aspect.value=camera.aspect;material.uniforms.motion.value=window.habitatOptions?.motion??.55;};
  scene.add(backdrop);
  return {obstacles:[],landmarks:[]};
}

export function createCobaltPlants(scene) {
  if(isReef())return createGouachePlants(scene);
  const rng=randomGenerator(2761), positions=[],uvs=[],indices=[];
  for(let i=0;i<140;i++) {
    const side=i%2?-1:1;
    const x=side*(6.3+rng()*4.4), z=.2+rng()*2.4, y=groundHeight(x,z)-.15;
    const height=.4+rng()*1.3,width=.028+rng()*.052, bend=(rng()-.5)*.7, base=positions.length/3;
    for(let k=0;k<=8;k++){
      const t=k/8;
      const silhouette=Math.pow(Math.sin(Math.PI*(.08+t*.92)),.7);
      for(const sign of [-1,1]) {positions.push(x+bend*t*t+sign*width*silhouette, y+height*t,z);uvs.push(t,(sign+1)/2);}
      if(k<8){const b=base+k*2;indices.push(b,b+1,b+2,b+1,b+3,b+2);}
    }
  }
  const geometry=new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));geometry.setIndex(indices);
  const material=new THREE.ShaderMaterial({uniforms:{time:waterTime},side:THREE.DoubleSide,
    vertexShader:`uniform float time;varying vec2 leafUV;varying vec3 leafPoint;void main(){leafUV=uv;leafPoint=position;float tip=uv.x;vec3 p=position;p.x+=sin(time*.48+p.x*.8+p.z)*.10*tip*tip;p.z+=cos(time*.36+p.x)*.055*tip;gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}`,
    fragmentShader:`varying vec2 leafUV;varying vec3 leafPoint;
      float hash(vec3 p){return fract(sin(dot(p,vec3(127.1,311.7,74.7)))*43758.5453);}
      void main(){
        float volume=pow(max(0.,sin(leafUV.y*3.14159)),.7);
        float light=(.13+.87*volume)*(.3+.7*smoothstep(.0,.8,leafUV.x));
        vec3 pigment=mix(vec3(.005,.028,.009),vec3(.038,.19,.024),hash(floor(leafPoint*1.7))*.32+.42);
        float grain=hash(floor(leafPoint*370.));
        float ink=mix(.25,1.5,smoothstep(.06,.95,grain));
        gl_FragColor=vec4(pigment*light*ink,1.);
      }`});
  if(isReef())material.fragmentShader=material.fragmentShader.replace('vec3(.005,.028,.009),vec3(.038,.19,.024)','vec3(.012,.025,.016),vec3(.09,.16,.045)');
  const mesh=new THREE.Mesh(geometry,material);mesh.name='Cobalt living reeds';scene.add(mesh);
  return {mesh,thickets:[],stats:{triangles:indices.length/3,vertices:positions.length/3}};
}

// Rest-position grain sticks to the fish as it swims. No metallic, wet-eye or
// translucent scale shader: the silhouette is shaded like the illustrated stone.
export function styleCobaltFish(scene) {
  const meshes=[scene.getObjectByName('Silver-blue freshwater fish'),scene.getObjectByName('Attached translucent fish fins')];
  for(const mesh of meshes){
    const tones=Float32Array.from({length:mesh.count},(_,i)=>(i*7%24)/24);
    mesh.geometry.setAttribute('aCobaltTone',new THREE.InstancedBufferAttribute(tones,1));
    const material=mesh.material;
    if(isReef())mesh.geometry.scale(1,1.28,.7);
    const swimming=material.onBeforeCompile;
    material.transparent=false;material.opacity=1;material.depthWrite=true;
    material.metalness=0;material.roughness=1;material.envMapIntensity=0;
    if('clearcoat' in material)material.clearcoat=0;
    if('iridescence' in material)material.iridescence=0;
    material.onBeforeCompile=(shader)=>{
      swimming(shader);
      shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nattribute float aCobaltTone;varying float vCobaltTone;');
      shader.vertexShader=shader.vertexShader.replace('void main() {','void main() {\nvCobaltTone=aCobaltTone;');
      shader.fragmentShader=`
        varying vec3 vNormal;varying vec3 vSkinPoint;varying vec2 vFishUV;varying float vFishPart;varying float vCobaltTone;
        float grainHash(vec3 p){return fract(sin(dot(p,vec3(127.1,311.7,74.7)))*43758.5453);}
        void main(){
          vec3 pigment;
          if(vCobaltTone<.42)pigment=vec3(.018,.24,.022);
          else if(vCobaltTone<.67)pigment=vec3(.006,.032,.64);
          else if(vCobaltTone<.88)pigment=vec3(.73,.013,.003);
          else pigment=vec3(.59,.53,.37);
          vec3 n=normalize(vNormal)*(gl_FrontFacing?1.:-1.);
          float light=smoothstep(-.48,.82,dot(n,normalize(vec3(-.35,.8,.45))));
          float volume=.07+.93*pow(light,1.35);
          float grain=grainHash(floor(vSkinPoint*460.));
          float clump=grainHash(floor(vSkinPoint*150.));
          float ink=mix(.32,1.48,smoothstep(.08,.94,grain))*(.8+.35*clump);
          vec3 color=pigment*volume*ink;
          // A simple dark eye mark, without the original silver ring and corneal gloss.
          if(vFishPart>6.5&&vFishPart<8.5)color=vec3(.002,.006,.003)*(0.6+grain*.6);
          if(vFishPart>8.5&&vFishPart<11.5)color=pigment*volume*.38*ink;
          if(vFishPart>.5&&vFishPart<6.5){
            float rib=.88+.12*sin(vFishUV.x*38.);
            color*=rib;
          }
          gl_FragColor=vec4(color,1.);
        }`;
      if(isReef())shader.fragmentShader=gouacheFishFragment;
    };
    material.customProgramCacheKey=()=> isReef()?'reef-gouache-fish-v2':'cobalt-illustrated-fish-v2';
    material.needsUpdate=true;
  }
}

export function createCobaltParticles(scene) {
  const rng=randomGenerator(7433),count=150,positions=[],seeds=[],sizes=[],kinds=[];
  for(let i=0;i<count;i++){
    const bubble=i<45;
    positions.push(-8+rng()*16,.5+rng()*8,-3+rng()*5);
    seeds.push(rng());sizes.push(bubble?.06+rng()*.08:.009+rng()*.016);kinds.push(bubble?1:0);
  }
  const geometry=new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  geometry.setAttribute('seed',new THREE.Float32BufferAttribute(seeds,1));
  geometry.setAttribute('size',new THREE.Float32BufferAttribute(sizes,1));
  geometry.setAttribute('kind',new THREE.Float32BufferAttribute(kinds,1));
  const uniforms={time:waterTime,pixelScale:{value:1000}};
  const material=new THREE.ShaderMaterial({uniforms,transparent:true,depthWrite:false,
    vertexShader:`uniform float time,pixelScale;attribute float seed,size,kind;varying float vSeed,vKind,vFade;
      void main(){vec3 p=position;vSeed=seed;vKind=kind;
      p.y=.4+mod(position.y+time*(kind>.5?.42+seed*.35:.035),8.8);
      p.x+=sin(time*.35+seed*30.)*.16;
      vFade=smoothstep(.4,1.,p.y)*(1.-smoothstep(8.1,9.2,p.y));
      vec4 mv=modelViewMatrix*vec4(p,1.);gl_Position=projectionMatrix*mv;
      gl_PointSize=max(1.8,size*pixelScale/-mv.z);}`,
    fragmentShader:`varying float vSeed,vKind,vFade;
      float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
      void main(){vec2 p=(gl_PointCoord-.5)*2.;float r=length(p);if(r>1.)discard;
      float g=hash(floor(gl_PointCoord*24.)+vSeed*73.);
      vec3 pigment=vSeed<.6?vec3(.018,.095,.30):vec3(.035,.16,.045);
      float alpha;
      if(vKind>.5){
        float ring=smoothstep(.42,.73,r)*(1.-smoothstep(.83,1.,r));
        float crescent=smoothstep(-.6,.6,-p.x-p.y)*ring;
        pigment=mix(pigment,vec3(.36,.34,.22),crescent*.52);
        alpha=(ring*.56+.075)*(0.5+g*.7)*vFade;
      }else{alpha=(1.-smoothstep(.0,1.,r))*.3*vFade;}
      gl_FragColor=vec4(pigment*(.65+g*.7),alpha);
    }`});
  if(isReef())material.fragmentShader=material.fragmentShader.replace('vec3(.018,.095,.30):vec3(.035,.16,.045)','vec3(.055,.13,.19):vec3(.15,.17,.10)');
  if(isReef())material.fragmentShader=gouacheBubbleFragment;
  const points=new THREE.Points(geometry,material);points.frustumCulled=false;points.name='Cobalt stippled bubbles';scene.add(points);
  return {update(pixelScale){uniforms.pixelScale.value=pixelScale;}};
}

